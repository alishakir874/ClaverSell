﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntity.UserManagement
{
   public class UserLogin
    {
        public int userId { get; set; }

        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phoneno { get; set; }
        public string loginusername { get; set; }
        public string loginpassword { get; set; }
    }
}
