﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Product
{
   public class ProductMasterEntity
    {

        public ProductMasterEntity()
        {
            new List<ProductCategory>();
        }
        public List<ProductCategory> productCategory { get; set; }
    }

    public class ProductCategory
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
    public class ProductEntity :CommonClass
    {
        public int ProductId { get; set; }
        public int StoreId { get; set; }
        public string ProductCode { get; set; }
        public string ProductTitle { get; set; }
        public int Status { get; set; }
        public int AvailableQty { get; set; }
        public string SupplierSKU { get; set; }

        public string Manufacturer { get; set; }
        public string OriginSource { get; set; }
        public decimal MarketPrice { get; set; }
        public decimal SellingPrice { get; set; }
        public decimal PurchasePrice { get; set; }
        public decimal Profit { get; set; }
        public decimal Margin { get; set; }
        public string ShippingDays { get; set; }
        public string BrandName { get; set; }
        public decimal PWeight { get; set; }
        public string Dimension { get; set; }

        public string ProductDescription { get; set; }
        public string ProductPoint { get; set; }
        public string ImageName { get; set; }
        public string MainImage { get; set; }
        public int CategoryId { get; set; }
    }
}
