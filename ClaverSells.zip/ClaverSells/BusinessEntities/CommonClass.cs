﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities
{
    public class CommonClass
    {
        public string SCreatedDate { get; set; }
        public string SCreatedBy { get; set; }
        
    }
}
