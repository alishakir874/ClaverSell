﻿using BusinessEntity.UserManagement;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DLLayer.UserManagement
{
    public class UserDL
    {
        string cs = ConfigurationManager.ConnectionStrings["ConnectionClaverSell"].ToString();

        #region Role
        public List<RolesEntity> getRoleList()
        {
            List<RolesEntity> objget = new List<RolesEntity>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                RolesEntity Obj;

                con.Open();
                SqlCommand cmd = new SqlCommand("spGetRoles", con);
                cmd.CommandType = CommandType.StoredProcedure;

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Obj = new RolesEntity();

                        Obj.RoleId = Convert.ToInt32(dr["RoleId"]);
                        Obj.RoleName = dr["RoleName"].ToString();
                        Obj.SCreatedDate = dr["CreatedDate"].ToString();
                        Obj.SCreatedBy = dr["CreatedBy"].ToString();
                        objget.Add(Obj);
                    }

                    return objget;
                }
            }
        }

        public int AddRole(RolesEntity model)
        {

            using (SqlConnection myConnection = new SqlConnection(cs))
            {

                using (SqlCommand cmd = new SqlCommand("spAddRole", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    cmd.Parameters.AddWithValue("@RoleName", model.RoleName);
                    cmd.Parameters.AddWithValue("@CreatedBy", 1);
                   
                    return (int)cmd.ExecuteScalar();

                }
            }
        }

        #endregion

        #region UserLogin
    
        public string ValidateUserLogin(UserLogin usermodel)
        {

            using (SqlConnection myConnection = new SqlConnection(cs))
            {

                using (SqlCommand cmd = new SqlCommand("spValidateUserLogin", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    cmd.Parameters.AddWithValue("@loginusername", usermodel.loginusername);
                    cmd.Parameters.AddWithValue("@loginpassword", usermodel.loginpassword);

                    return (string)cmd.ExecuteScalar();

                }
            }
        }

        public UserLogin getUserDetailbyemail(string username)
        {
            UserLogin objModel = new UserLogin();

            using (SqlConnection myConnection = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("spgetUserDetailbyemail", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    SqlParameter Inhouse = cmd.Parameters.AddWithValue("@username", username);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            

                            objModel.userId = Convert.ToInt32(dr["UserId"].ToString());
                            objModel.loginusername = username;
                            objModel.firstName = dr["FirstName"].ToString();
                            objModel.lastName = dr["LastName"].ToString();
                            objModel.phoneno = dr["Phoneno"].ToString();

                        }
                      
                    }

                }
            }
            return objModel;
        }

        public string UpdateUser(UserLogin model)
        {

            using (SqlConnection myConnection = new SqlConnection(cs))
            {

                using (SqlCommand cmd = new SqlCommand("spUpdateUser", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    cmd.Parameters.AddWithValue("@UserId", model.userId);
                    cmd.Parameters.AddWithValue("@firstname", model.firstName);
                    cmd.Parameters.AddWithValue("@lastname", model.lastName);

                    return (string)cmd.ExecuteScalar();

                }
            }
        }

        #endregion
    }
}
