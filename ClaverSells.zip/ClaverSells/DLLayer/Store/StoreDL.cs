﻿using BusinessEntity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLLayer.Store
{
    public class StoreDL
    {

        string cs = ConfigurationManager.ConnectionStrings["ConnectionClaverSell"].ToString();

        public string IsUserExists(string storename)
        {
            string StoreNameInUse = "";
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spstoreNameExists", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter()
                {
                    ParameterName = "@storename",
                    Value = storename
                });

                con.Open();
               return StoreNameInUse = (string)cmd.ExecuteScalar();
            }
        }

        public string StoreRegistration(StoreEntity model)
        {
            using (SqlConnection myConnection = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("spStoreRegistration", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    cmd.Parameters.AddWithValue("@storename", model.storename);
                    cmd.Parameters.AddWithValue("@Storeemail", model.storeemail);
                    cmd.Parameters.AddWithValue("@Storephone", model.storephoneno);
                    cmd.Parameters.AddWithValue("@Storepassword", model.password);
                    cmd.Parameters.AddWithValue("@ReferredBy", model.ReferredBy);

                    return (string)cmd.ExecuteScalar();
                }
            }

        }



        public StoreEntity getStoreDetailbyemail(string username)
        {
            StoreEntity objModel = new StoreEntity();

            using (SqlConnection myConnection = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("spgetStoreDetailbyemail", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    SqlParameter Inhouse = cmd.Parameters.AddWithValue("@username", username);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            objModel.storeId = Convert.ToInt32(dr["StoreId"].ToString());
                            objModel.storename = dr["Storename"].ToString();
                            objModel.storeemail = dr["Username"].ToString();
                            objModel.storephoneno = Convert.ToInt32(dr["Storephone"].ToString());
                            objModel.firstName = dr["FirstName"].ToString();
                            objModel.lastName = dr["LastName"].ToString();
                            objModel.ReferredBy = dr["ReferredBy"].ToString();
                            objModel.ReferCode = dr["ReferCode"].ToString();

                            objModel.BusinessId = Convert.ToInt32(dr["BusinessId"].ToString());
                            objModel.PanCard = dr["PanCard"].ToString();
                            objModel.GST = dr["GST"].ToString();
                            objModel.ShippingAddress = dr["ShippingAddress"].ToString();
                            objModel.BusinessAddress = dr["BusinessAddress"].ToString();
                            objModel.ShippingContact = dr["ShippingContact"].ToString();

                            objModel.AccountHolderName = dr["AccountHolderName"].ToString();
                            objModel.BankName = dr["BankName"].ToString();
                            objModel.IFSCCode = dr["IFSCCode"].ToString();
                            objModel.AccountNumber = dr["AccountNumber"].ToString();
                        }

                    }

                }
            }
            return objModel;
        }


        public string UpdateBusiness(StoreEntity model)
        {

            using (SqlConnection myConnection = new SqlConnection(cs))
            {

                using (SqlCommand cmd = new SqlCommand("spUpdateBusiness", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    cmd.Parameters.AddWithValue("@storeid", model.storeId);
                    cmd.Parameters.AddWithValue("@pancard", model.PanCard);
                    cmd.Parameters.AddWithValue("@gst", model.GST);
                    cmd.Parameters.AddWithValue("@businessAddress", model.BusinessAddress);
                    cmd.Parameters.AddWithValue("@shippingAddress", model.ShippingAddress);
                    cmd.Parameters.AddWithValue("@shippingContact", model.ShippingContact);

                    return (string)cmd.ExecuteScalar();

                }
            }
        }
        public string UpdateAccount(StoreEntity model)
        {

            using (SqlConnection myConnection = new SqlConnection(cs))
            {

                using (SqlCommand cmd = new SqlCommand("spUpdateAccount", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    cmd.Parameters.AddWithValue("@storeid", model.storeId);
                    cmd.Parameters.AddWithValue("@AccountHolderName", model.AccountHolderName);
                    cmd.Parameters.AddWithValue("@BankName", model.BankName);
                    cmd.Parameters.AddWithValue("@IFSCCode", model.IFSCCode);
                    cmd.Parameters.AddWithValue("@AccountNumber", model.AccountNumber);

                    return (string)cmd.ExecuteScalar();

                }
            }
        }

    }
}
