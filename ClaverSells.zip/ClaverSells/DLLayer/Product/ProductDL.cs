﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntities.Product;

namespace DLLayer.Product
{
   public class ProductDL
    {
        string cs = ConfigurationManager.ConnectionStrings["ConnectionClaverSell"].ToString();

        public List<ProductCategory> getproductcategorylist()
        {
            List<ProductCategory> productcategorylist = new List<ProductCategory>();

            ProductCategory productcategoryobj;

            using (SqlConnection myConnection = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("spGetProductCategory", myConnection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    myConnection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            productcategoryobj = new ProductCategory();
                            productcategoryobj.CategoryId = Convert.ToInt32(dr["CategoryId"].ToString());
                            productcategoryobj.CategoryName = dr["CategoryName"].ToString();

                            productcategorylist.Add(productcategoryobj);
                        }

                    }

                }
            }
            return productcategorylist;
        }

    }
}
