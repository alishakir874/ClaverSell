﻿using BusinessEntities.Product;
using DLLayer.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ClaverSells.Controllers
{
    public class ProductController : Controller
    {
        ProductDL objProductDL = new ProductDL();
        // GET: Product
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult NewProduct()
        {
            return View();
        }

        public ActionResult getProductCategory()
        {
            List<ProductCategory> productcatList = objProductDL.getproductcategorylist();
            return Json(productcatList, JsonRequestBehavior.AllowGet);
        }
        
    }
}