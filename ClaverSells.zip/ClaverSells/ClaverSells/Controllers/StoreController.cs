﻿using BusinessEntity;
using BusinessEntity.UserManagement;
using ClaverSells.Models;
using ClaverSells.Models.Store;
using ClaverSells.Models.UserManagment;
using DLLayer.Store;
using DLLayer.UserManagement;
using System;
using System.Web.Mvc;

namespace ClaverSells.Controllers
{
    public class StoreController : Controller
    {

        StoreDL objStoreDL = new StoreDL();
        UserDL objUserDL = new UserDL();
        string errormessage;
        ErrorMsg errorobj = new ErrorMsg();

        // GET: Store
        public ActionResult StoreReg()
        {
            return View();
        }

        [HttpPost]
        public JsonResult CreateStore(StoreEntity model)
        {
            return Json(objStoreDL.StoreRegistration(model), JsonRequestBehavior.AllowGet);
        }
        public JsonResult IsUserExist(string storename)
        {
            return Json(objStoreDL.IsUserExists(storename), JsonRequestBehavior.AllowGet);
        }

        public ActionResult StoreDashboard()
        {
            if (!CheckError(out errormessage))
            {
                return RedirectToAction("Login", "Claver");
            }
            var usermodel = getusermodel(objUserDL.getUserDetailbyemail(Session["loginusername"].ToString()));
            var storemodel = getstoremodel(objStoreDL.getStoreDetailbyemail(Session["loginusername"].ToString()));

            return View(Tuple.Create(usermodel, storemodel));
        }
        public ActionResult ManageStore()
        {
            if (!CheckError(out errormessage))
            {
                return RedirectToAction("Login", "Claver");
            }

            var usermodel = getusermodel(objUserDL.getUserDetailbyemail(Session["loginusername"].ToString()));
            var storemodel = getstoremodel(objStoreDL.getStoreDetailbyemail(Session["loginusername"].ToString()));

            return View(Tuple.Create(usermodel, storemodel));
        }

        [HttpPost]
        public JsonResult UpdateStore(StoreEntity model,string action,string flag)
        {
            return Json(objStoreDL.StoreRegistration(model), JsonRequestBehavior.AllowGet);
        }

        public UserLoginModel getusermodel(UserLogin userentity)
        {
            UserLoginModel objmodel = new UserLoginModel();
            objmodel.userId = userentity.userId;
            objmodel.loginusername = userentity.loginusername;
            objmodel.firstName = userentity.firstName;
            objmodel.lastName = userentity.lastName;
            objmodel.phoneno = userentity.phoneno;

            return objmodel;
        }
        public StoreModel getstoremodel(StoreEntity storeentity)
        {
            StoreModel objmodel = new StoreModel();

            objmodel.storeId = storeentity.storeId;
            objmodel.storename = storeentity.storename;
            objmodel.storeemail = storeentity.storeemail;
            objmodel.storephoneno = storeentity.storephoneno;
            objmodel.firstName = storeentity.firstName;
            objmodel.lastName = storeentity.lastName;
            objmodel.ReferredBy = storeentity.ReferredBy;
            objmodel.ReferCode = storeentity.ReferCode;
            objmodel.BusinessId = storeentity.BusinessId;
            objmodel.PanCard = storeentity.PanCard;
            objmodel.GST = storeentity.GST;
            objmodel.ShippingAddress = storeentity.ShippingAddress;
            objmodel.ShippingContact = storeentity.ShippingContact;
            objmodel.BusinessAddress = storeentity.BusinessAddress;
            objmodel.AccountHolderName = storeentity.AccountHolderName;
            objmodel.BankName = storeentity.BankName;
            objmodel.IFSCCode = storeentity.IFSCCode;
            objmodel.AccountNumber = storeentity.AccountNumber;

            return objmodel;
        }


        public ActionResult UpdateBusiness(StoreEntity model)
        {
            if (CheckError(out errormessage))
            {
                errorobj.resultmessage = objStoreDL.UpdateBusiness(model);
                errorobj.errormessage = errormessage;
                return Json(errorobj, JsonRequestBehavior.AllowGet);
            }
            else
            {
                errorobj.errormessage = errormessage;
                return Json(errorobj, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult UpdateAccount(StoreEntity model)
        {
            if (CheckError(out errormessage))
            {
                errorobj.resultmessage = objStoreDL.UpdateAccount(model);
                errorobj.errormessage = errormessage;
                return Json(errorobj, JsonRequestBehavior.AllowGet);
            }
            else
            {
                errorobj.errormessage = errormessage;
                return Json(errorobj, JsonRequestBehavior.AllowGet);
            }
        }

        

        #region CommonMethod
        public bool CheckError(out string errormessage)
        {
            if (Session["loginusername"] == null)
            {
                errormessage = "Session empty";
                return false;
            }
            else
            {
                errormessage = "Success";
                return true;
            }
        }
        #endregion

    }
}