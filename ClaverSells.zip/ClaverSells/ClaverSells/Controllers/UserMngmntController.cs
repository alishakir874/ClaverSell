﻿using BusinessEntity.UserManagement;
using ClaverSells.Models;
using DLLayer.Store;
using DLLayer.UserManagement;
using System.Web.Mvc;

namespace ClaverSells.Controllers
{
    public class UserMngmntController : Controller
    {
        UserDL objUserDL = new UserDL();
        StoreDL objUserDLStore = new StoreDL();
        string errormessage;
       
        ErrorMsg errorobj = new ErrorMsg();
        // GET: UserMngmnt
        public ActionResult Index()
        {
            var rolelist = objUserDL.getRoleList();

            return View(rolelist);
        }

        [HttpPost]
        public ActionResult CreateRole(RolesEntity model)
        {
            int i = 0;
            if (ModelState.IsValid)
            {
                i = objUserDL.AddRole(model);
            }

            if (i == 1)
            {
                return PartialView("_RolesList", objUserDL.getRoleList());
            }
            else
            {
                return View("Index");
            }

        }

        public ActionResult Login()
        {
            return View();
        }
       

        [HttpPost]
        public ActionResult ValidateUserLogin(UserLogin model)
        {
            string result = "";

            result = objUserDL.ValidateUserLogin(model);

            if (result == "Success")
            {
                var usermodel = objUserDL.getUserDetailbyemail(model.loginusername);
                var storemodel = objUserDLStore.getStoreDetailbyemail(model.loginusername);

                //from usermodel
                Session["userId"] = usermodel.userId;
                Session["loginusername"] = model.loginusername;
                Session["firstName"] = usermodel.firstName;
                Session["lastName"] = usermodel.lastName;

                //from storemodel
                Session["storeId"] = storemodel.storeId;
                Session["storename"] = storemodel.storename;
                Session["storeemail"] = storemodel.storeemail;
                Session["ReferredBy"] = storemodel.ReferredBy;
                Session["ReferCode"] = storemodel.ReferCode;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Logout()
        {
            return RedirectToAction("Index","Claver");
        }

        public ActionResult UpdateUser(UserLogin model)
        {
            if (CheckError(out errormessage))
            {
                errorobj.resultmessage = objUserDL.UpdateUser(model);
                errorobj.errormessage = errormessage;
                return Json(errorobj, JsonRequestBehavior.AllowGet);
            }
            else
            {
                errorobj.errormessage = errormessage;
                return Json(errorobj, JsonRequestBehavior.AllowGet);
            }
        }

        #region CommonMethod
        public bool CheckError(out string errormessage)
        {
            if (Session["loginusername"] == null)
            {
                errormessage = "Session empty";
                return false;
            }
            else
            {
                errormessage = "Success";
                return true;
            }
        }
        #endregion

    }
}