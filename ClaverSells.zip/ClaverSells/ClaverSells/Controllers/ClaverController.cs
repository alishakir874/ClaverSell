﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ClaverSells.Controllers
{
    public class ClaverController : Controller
    {
        // GET: Claver
        public ActionResult Index()
        {
            return View();
        }
    }
}