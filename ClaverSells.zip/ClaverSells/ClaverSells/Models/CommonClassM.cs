﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClaverSells.Models
{
    public class CommonClassM
    {
        public string SCreatedDate { get; set; }
        public string SCreatedBy { get; set; }
    }

    public class ErrorMsg
    {
        public int errorStatus { get; set; }
        public string errormessage { get; set; }
        public string resultmessage { get; set; }

    }


}