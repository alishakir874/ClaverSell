﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClaverSells.Models.Store
{
    public class StoreModel
    {
        public int storeId { get; set; }
        public string storename { get; set; }
        public string storeemail { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int storephoneno { get; set; }
        public string password { get; set; }
        public string confirmpassword { get; set; }
        public string ReferredBy { get; set; }
        public string ReferCode { get; set; }
        public int BusinessId { get; set; }
        public string PanCard { get; set; }
        public string GST { get; set; }
        public string BusinessAddress { get; set; }
        public string ShippingAddress { get; set; }
        public string ShippingContact { get; set; }
        public string AccountHolderName { get; set; }
        public string BankName { get; set; }
        public string IFSCCode { get; set; }
        public string AccountNumber { get; set; }
    }
}