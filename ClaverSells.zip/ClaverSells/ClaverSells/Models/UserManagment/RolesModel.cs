﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClaverSells.Models.UserManagment
{
    public class RolesModel
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
    }
}