﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClaverSells.Models.UserManagment
{
    public class UserLoginModel
    {
        public int userId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phoneno { get; set; }
        public string loginusername { get; set; }
        public string loginpassword { get; set; }
    }
}